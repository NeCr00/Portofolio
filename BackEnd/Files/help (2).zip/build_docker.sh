#!/bin/bash
docker rm -f web_help
docker build -t web_help . && \
docker run --name=web_help --rm -p1337:80 -it web_help