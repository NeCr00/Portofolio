var input = document.getElementById('command');

document.getElementById("command").addEventListener('keydown', (event) => {
  if (event.keyCode === 13) {
    //document.removeEventListener('keydown', onKeyHandler);
    pingHost(input.value);
  }
});

function pingHost(host) {
  let data = "ip=" + host;

  fetch('/submit.php', {
      method: 'POST',
      body: data,
      headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
      }
  })
  .then(resp => resp.json())
  .then(data => {
      var output = document.getElementById("console-output");
      output.innerHTML = data.message;
  });
}