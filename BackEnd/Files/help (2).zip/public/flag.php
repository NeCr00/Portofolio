<?php
$flag = "INSSEC{fake_flag}";
?>
