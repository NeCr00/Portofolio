<?php
include_once('flag.php');

if (isset($_POST['ip'])) {
    if (preg_match("/[\!\@\#\$\%\^\&\*\(\)\/\\\?\>\<\;\+\=\_\{\}\[\]\`\~\|\,]/i", $_POST['ip'])) {
        die(json_encode(array('error' => 1, 'message' => "Forbidden Characters Detected")));
    } else {
       $command = 'curl ' . $_POST['ip'];
       exec($command, $output);
       echo(json_encode(array('error' => 0, 'message' => $output )));
    }
}
?>